import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.Random;


public class NormalFish implements SceneObject {
    Image[] fishImage = new Image[6];
    private double unchangedTotalTime = 0;
    private double totalTime = 0;
    public double frameRateFish = 8 * 1e-9;
    public double positionX = 0;
    public double startingPositionX = 0;
    public double startingPositionY = 1;
    public boolean fishDisapear = false;
    private int lostFishCount = 0;

    private Image imageFish00 = new Image("/images/fish/00.png");
    private Image imageFish01 = new Image("/images/fish/01.png");
    private Image imageFish02 = new Image("/images/fish/02.png");
    private Image imageFish03 = new Image("/images/fish/03.png");
    private Image imageFish04 = new Image("/images/fish/04.png");
    private Image imageFish05 = new Image("/images/fish/05.png");
    private Image imageFish06 = new Image("/images/fish/06.png");
    private Image imageFish07 = new Image("/images/fish/07.png");


    Rectangle rect = new Rectangle(0, 96 + Math.random() * 288, 50, 50);


    private double vx = 0;
    private double ax = 0;
    private double vy = -1 * (100 + Math.random() * 100);
    private double ay = 100;


    public NormalFish() {
        Image fish;
        Color color = changeColor();
        double poissonRandom = Math.random() * 8;
        if (poissonRandom < 1) {
            fish = imageFish00;
        } else if (poissonRandom >= 1 && poissonRandom < 2) {
            fish = imageFish01;
        } else if (poissonRandom >= 2 && poissonRandom < 3) {
            fish = imageFish02;
        } else if (poissonRandom >= 3 && poissonRandom < 4) {
            fish = imageFish03;
        } else if (poissonRandom >= 4 && poissonRandom < 5) {
            fish = imageFish04;
        } else if (poissonRandom >= 5 && poissonRandom < 6) {
            fish = imageFish05;
        } else if (poissonRandom >= 6 && poissonRandom < 7) {
            fish = imageFish06;
        } else {
            fish = imageFish07;
        }

        for (int i = 0; i < fishImage.length; i++) {
            fishImage[i] = ImageHelpers.colorize(fish, color);
        }
    }


    public void imagePoisson(boolean flipperImage) {

        Color color = changeColor();

        double normalTypeFish = Math.random();

        if (normalTypeFish < 0.125) {
            for (int i = 0; i < fishImage.length; i++) {

                if (flipperImage) {
                    fishImage[i] = ImageHelpers.colorize(ImageHelpers.flop(imageFish00), color);

                } else {
                    fishImage[i] = ImageHelpers.colorize(imageFish00, color);
                }
            }
        } else if (normalTypeFish >= 0.125 && normalTypeFish < 0.25) {
            for (int i = 0; i < fishImage.length; i++) {

                if (flipperImage) {
                    fishImage[i] = ImageHelpers.colorize(ImageHelpers.flop(imageFish01), color);
                } else {
                    fishImage[i] = ImageHelpers.colorize(imageFish01, color);
                }
            }
        } else if (normalTypeFish >= 0.25 && normalTypeFish < 0.375) {
            for (int i = 0; i < fishImage.length; i++) {

                if (flipperImage) {
                    fishImage[i] = ImageHelpers.colorize(ImageHelpers.flop(imageFish02), color);
                } else {
                    fishImage[i] = ImageHelpers.colorize(imageFish02, color);
                }
            }
        } else if (normalTypeFish >= 0.375 && normalTypeFish < 0.5) {
            for (int i = 0; i < fishImage.length; i++) {
                if (flipperImage) {
                    fishImage[i] = ImageHelpers.colorize(ImageHelpers.flop(imageFish03), color);
                } else {
                    fishImage[i] = ImageHelpers.colorize(imageFish03, color);
                }
            }
        } else if (normalTypeFish >= 0.5 && normalTypeFish < 0.625) {
            for (int i = 0; i < fishImage.length; i++) {
                if (flipperImage) {
                    fishImage[i] = ImageHelpers.colorize(ImageHelpers.flop(imageFish04), color);
                } else {
                    fishImage[i] = ImageHelpers.colorize(imageFish04, color);
                }
            }
        } else if (normalTypeFish >= 0.625 && normalTypeFish < 0.75) {
            for (int i = 0; i < fishImage.length; i++) {
                if (flipperImage) {
                    fishImage[i] = ImageHelpers.colorize(ImageHelpers.flop(imageFish05), color);
                } else {
                    fishImage[i] = ImageHelpers.colorize(imageFish05, color);
                }
            }
        } else if (normalTypeFish >= 0.75 && normalTypeFish < 0.875) {
            for (int i = 0; i < fishImage.length; i++) {
                if (flipperImage) {
                    fishImage[i] = ImageHelpers.colorize(ImageHelpers.flop(imageFish06), color);
                } else {
                    fishImage[i] = ImageHelpers.colorize(imageFish06, color);
                }
            }
        } else {
            for (int i = 0; i < fishImage.length; i++) {
                if (flipperImage) {
                    fishImage[i] = ImageHelpers.colorize(ImageHelpers.flop(imageFish07), color);
                } else {
                    fishImage[i] = ImageHelpers.colorize(imageFish07, color);
                }
            }
        }
    }

    @Override
    public void update(double dt, double level) {
        float tmp = (float) Math.pow(level, (double) 1 / 3);

        totalTime += dt;
        unchangedTotalTime += dt;

        getCounterLoss();

        if (totalTime >= 0 &&
                totalTime < 3) {

            if (!fishDisapear) {
                startingPositionY = changeStartingY();
                positionX = Math.random();
                double vx = 100 * tmp + 200;

                if (startingPositionX == 0) {
                    this.vx = vx;
                } else {
                    this.vx = vx * -1;
                }

                this.vy += (ay * dt);

                rect.setX(rect.getX() + this.vx * dt);

                rect.setY(rect.getY() + vy * dt);


                if (rect.getX() + rect.getWidth() > 640) {
                    setVx(getVx() * -1);
                }

                if (rect.getX() < 0) {
                    setVx(getVx() * -1);
                }
            } else {
                lostFishCount = 0;
                fishDisapear = false;
                rect.setY(startingPositionY);
                rect.setX(changeStartingX());
                this.vy = -1 * (100 + Math.random() * 100);
                startingPositionX = rect.getX();
            }

        } else {
            lostFishCount = 0;
            totalTime = 0;
            rect.setY(startingPositionY);
            rect.setX(changeStartingX());
            this.vy = -1 * (100 + Math.random() * 100);
            startingPositionX = rect.getX();

        }
    }

    @Override
    public void draw(GraphicsContext context) {

        if (!fishDisapear) {
            int frame = (int) (unchangedTotalTime * frameRateFish);

            Image img = fishImage[(frame % fishImage.length)];
            context.drawImage(img, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
        }


    }

    public double changeStartingY() {
        return (96 + Math.random() * 288);
    }

    public double changeStartingX() {
        double rightOrLeft = Math.random();


        if (rightOrLeft < 0.5) {
            imagePoisson(false);
            return 0;

        }
        imagePoisson(true);
        return 640;
    }

    public Color changeColor() {
        Random random = new Random();
        float r = random.nextFloat();
        float g = random.nextFloat();
        float b = random.nextFloat();

        return new Color(r, b, g, 1);
    }

    public int getCounterLoss() {
        if (startingPositionX == 0) {
            if (rect.getX() >= 680 ||
                    rect.getY() <= -40 ||
                    rect.getY() + rect.getHeight() >= 520) {
                lostFishCount += 1;
                return lostFishCount;
            }
        } else {
            if (((int) rect.getX() <= -40 ||
                    ((int) rect.getY() <= -40 ||
                            (int) rect.getY() + rect.getHeight() >= 520))) {
                lostFishCount += 1;
                return lostFishCount;
            }
        }
        return 0;
    }

    public double getVx() {
        return vx;
    }

    public double getVy() {
        return vy;
    }

    public double getAx() {
        return ax;
    }

    public double getAy() {
        return ay;
    }


    public void setVx(double vx) {
        this.vx = vx;
    }

    public void setVy(double vy) {
        this.vy = vy;
    }

    public void setAx(double ax) {
        this.ax = ax;
    }

    public void setAy(double ay) {
        this.ay = ay;
    }

}
