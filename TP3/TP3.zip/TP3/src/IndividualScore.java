public class IndividualScore implements Comparable{
    public String name;
    public int score;

    public IndividualScore(String name, int score) {
        this.name = name;
        this.score = score;
    }

    @Override
    public int compareTo(Object o) {
        IndividualScore individualScore = (IndividualScore) o;
        return Integer.compare(individualScore.score, score);

    }
    public String formatter(int position){
        return String.format("#%s - %s - %s", position + 1, name, score);
    }
}
