import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

import java.util.ArrayList;

public class BubbleGroup implements SceneObject {

    ArrayList<CircleData> circleData = new ArrayList<>();
    private double totalTime = 0;

    //initiallise un groupe contenant 5 bulles
    public BubbleGroup() {
        Color colorBulles = Color.rgb(0, 0, 255, 0.4);
        double groupX = Math.random() * 640;

        for (int j = 0; j < 5; j++) {
            double sign = 1;
            if (Math.random() < 0.5) {
                sign = -1;
            }
            double radius = 10 + (Math.random() * 30);

            circleData.add(j, new CircleData(radius,
                    groupX + (sign * (Math.random() * 20)),
                    440 - (Math.random() * 10),
                    colorBulles));

            //empecher les bulles de depasser l'ecran du cote droit
            if (circleData.get(j).getCenterX() > 640) {
                circleData.get(j).setCenterX(640 - circleData.get(j).getRadius() * 2);
            }

            if ((circleData.get(j).getCenterX() + circleData.get(j).getRadius()) > 640) {
                circleData.get(j).setCenterX(640 - (circleData.get(j).getRadius()));
            }


            //empecher les bulles de depasser l'ecran du cote gauche
            if (circleData.get(j).getCenterX() < 0) {
                circleData.get(j).setCenterX(circleData.get(j).getRadius());
            }

            if ((circleData.get(j).getCenterX() + circleData.get(j).getRadius()) < 0) {
                circleData.get(j).setCenterX(circleData.get(j).getRadius() * 2);
            }
        }
    }

    @Override
    public void update(double dt, double level) {
        totalTime += dt;

        for (CircleData circleData : this.circleData) {
            circleData.setCenterY(circleData.getCenterY() - dt * circleData.getVy());
        }

        //les bulles n'apparaissent sur l'ecran qu'a chaque 3 secondes
        if (totalTime >= 3) {
            totalTime = 0;
            double sign = 1;
            if (Math.random() < 0.5) {
                sign = -1;
            }
            for (CircleData circleData : this.circleData) {
                double groupX = Math.random() * 640;
                circleData.changeSpeed();

                //le centreX de chaque bulle ne depasse pas
                // +- 20 du x du groupe où ils appartiennent
                circleData.setCenterX(groupX + (sign * Math.random() * 20));

                if (circleData.getCenterX() > 640) {
                    circleData.setCenterX(640 - circleData.getRadius());
                }
                if ((circleData.getCenterX() + circleData.getRadius()) > 640) {
                    circleData.setCenterX(640 - (circleData.getRadius()) * 2);
                }

                circleData.setCenterY(480);
            }
        }
    }

    @Override
    public void draw(GraphicsContext context) {

        for (CircleData circleData : this.circleData) {
            context.setFill(circleData.getColor());
            context.fillOval(circleData.getCenterX(),
                    circleData.getCenterY(),
                    circleData.getRadius(),
                    circleData.getRadius());
        }
    }
}
