import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;

public class Controller {
    Game game = new Game();

    public void update(double dt){
        game.update(dt);}

    public void draw(GraphicsContext context){
        game.draw(context);}

    public void mouseMoved(MouseEvent event){
        game.mouseMoved(event);
    }

    public void mouseClicked(MouseEvent event){
        game.mouseClicked(event);
    }

    public void keyPressed(KeyCode key) {
        game.keyPressed(key);
    }

    public boolean returnScore() {
        return game.returnScore();
    }

}
