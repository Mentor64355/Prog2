import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

import java.util.ArrayList;

public class Scene implements SceneObject {

    private double vy = 50;
    private double ay = 2;
    private double y;
    public int points = 0;
    private ArrayList<Image> life = new ArrayList<>(3);
    public boolean drawLevelChange = false;
    double drawLevelTime = 0;

    private int level = 0;
    public boolean gameLost = false;
    public int lifeCount = 3;
    boolean gameOver = false;


    public Scene(double vy, double ay) {
        this.vy = vy;
        this.ay = ay;
        y = 0;
        for (int i = 0; i < 3; i++) {
            life.add(new Image("/images/fish/00.png"));
        }
    }

    public void update(double dt) {
        
        if (level == 0) {
            drawLevelChange = true;
            level = 1;
        }

        if (drawLevelChange) {
            drawLevelTime += dt;
        }

        if (drawLevelTime > 3) {
            drawLevelChange = false;
            drawLevelTime = 0;
            if (gameLost) {

                Data.gameScore = points;
                gameOver = true;
            }
        }

        double vy = 0;
        y = dt * vy;
    }

    @Override
    public void update(double dt, double level) {
    }

    @Override
    public void draw(GraphicsContext context) {

        context.clearRect(0, 0, Game.WIDTH, Game.HEIGHT);

        for (int i = 0; i < lifeCount; i++) {
            double x = 250 + i * 50;
            context.drawImage(life.get(i), x, 60, 40, 40);
        }

        context.setFill(Color.WHITE);
        context.setFont(Font.font("Arial Black", 35));
        context.fillText(" " + points, 300, 40);

        if (drawLevelChange && !gameLost) {
            context.fillText("LEVEL " + level, 250, 200);
        }

        if (gameLost) {
            drawLevelChange = true;
            context.setFill(Color.RED);
            context.setFont(Font.font("Arial Black", 48));
            context.fillText("GAME OVER", 180, 240);
        }
    }

    public void pointsUp() {
        points += 1;
        if (points % 5 == 0 && points != 0) {
            level += 1;
            drawLevelChange = true;
        }
    }

    public int getLevel() {
        return level;
    }

    public void loseLife() {
        lifeCount--;
        if (lifeCount == 0) {
            gameLost = true;
        }
    }

    public void levelUp() {
        level += 1;
    }

    public void lifeUp() {

        if (lifeCount < 3 && lifeCount > 0) {
            lifeCount += 1;
        }
    }

    public void lostGame() {
        gameLost = true;
        lifeCount = 0;
    }

    public double getVy() {
        return vy;
    }

    public void setVy(double vy) {
        this.vy = vy;
    }

    public double getAy() {
        return ay;
    }

    public void setAy(double ay) {
        this.ay = ay;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getPoints() {
        return points;
    }
}
