import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;

import javax.swing.text.html.ImageView;
import java.util.ArrayList;
import java.util.List;

public interface SceneObject {
    List<javafx.scene.image.ImageView> imageScene = new ArrayList<>();

    void update(double dt, double level);
    //void updateView(ImageView imageView);

    //void updateView(javafx.scene.image.ImageView imageView);

    void draw(GraphicsContext context);
    //void move(Pane root);
}
