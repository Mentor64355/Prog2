import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;

public class Target implements SceneObject {
    Rectangle rect;

    Image img;

    public Target() {
        img = new Image("/images/cible.png", 50, 50, false, true);
        rect = new Rectangle(320, 240, 50, 50);
    }

    @Override
    public void update(double dt, double level) { }

    @Override
    public void draw(GraphicsContext context) {
        context.drawImage(img, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
    }

    public void setPos(double x, double y) {
        this.rect.setX(x);
        this.rect.setY(y);
    }
}
