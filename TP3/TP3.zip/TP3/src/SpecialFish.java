import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.Random;


public class SpecialFish implements SceneObject {
    Image[] fishImage = new Image[6];
    double unchangedTotalTime = 0;
    double totalTime = 0;
    double frameRateFish = 8 * 1e-9;
    double positionX = 0;
    double startingPositionX = 0;
    double startingPositionY = 1;
    String fishType;
    double oscillationTime = 0;
    boolean fishDisapear = false;
    int lostFishCount;

    private Image imageCrabe = new Image("/images/crabe.png");
    private Image imageStar = new Image("/images/star.png");

    Rectangle rect = new Rectangle(0, 96 + Math.random() * 288, 50, 50);
    double[] startingPoint = {rect.getX(), rect.getY()};

    private double vx = 0;
    private double ax = 0;
    private double vy = -1 * (100 + Math.random() * 100);
    private double ay = 0;

    public SpecialFish() {
        fishType = "crabe";
        double special = Math.random();

        if (special < 0.5) {
            fishType = "star";
        }

        for (int i = 0; i < fishImage.length; i++) {
            fishImage[i] = new Image("/images/" + fishType + ".png");
        }

    }

    public void imagePoisson(boolean flipperImage) {

        Random random = new Random();
        float r = random.nextFloat();
        float g = random.nextFloat();
        float b = random.nextFloat();

        Color couleur = new Color(r, b, g, 1);

        double typeNormalPoisson = Math.random();

        if (typeNormalPoisson < 0.5) {
            fishType = "crabe";
            for (int i = 0; i < fishImage.length; i++) {
                if (flipperImage) {
                    fishImage[i] = ImageHelpers.colorize(ImageHelpers.flop(imageCrabe), couleur);
                } else {
                    fishImage[i] = ImageHelpers.colorize(imageCrabe, couleur);
                }
            }
        } else {
            fishType = "star";
            for (int i = 0; i < fishImage.length; i++) {
                if (flipperImage) {
                    fishImage[i] = ImageHelpers.colorize(ImageHelpers.flop(imageStar), couleur);
                } else {
                    fishImage[i] = ImageHelpers.colorize(imageStar, couleur);
                }

            }
        }
    }

    @Override
    public void update(double dt, double level) {
        double sign = 1;

        float tmp = (float) Math.pow(level, (double) 1 / 3);

        totalTime += dt;
        unchangedTotalTime += dt;
        oscillationTime += dt;

        getCounterLoss();

        if (fishType.equals("crabe")) {

            if (totalTime >= 0 && totalTime < 5) {
                if (!fishDisapear) {
                    if (oscillationTime > 0 && oscillationTime <= 0.25) {
                        sign = -1;
                    }
                    if (oscillationTime > 0.75) {
                        oscillationTime = 0;
                    }
                    startingPositionY = changeStartingY();
                    positionX = Math.random();
                    double vx = sign * (100 * tmp + 200) * 1.3;

                    if (startingPositionX == 0) {
                        this.vx = vx;
                    } else {
                        this.vx = vx * -1;
                    }

                    rect.setX(rect.getX() + this.vx * dt);
                } else {
                    lostFishCount = 0;
                    fishDisapear = false;
                    totalTime = 0;
                    rect.setY(startingPositionY);
                    rect.setX(changeStartingX());
                    startingPositionX = rect.getX();
                }
            } else {
                lostFishCount = 0;
                totalTime = 0;
                rect.setY(startingPositionY);
                rect.setX(changeStartingX());
                startingPositionX = rect.getX();
                startingPoint[0] = rect.getX();
                startingPoint[1] = rect.getY();

            }
        } else {
            if (totalTime >= 0 && totalTime < 5) {
                if (!fishDisapear) {

                    if (oscillationTime > 1) {
                        oscillationTime = 0;
                    }
                    startingPositionY = changeStartingY();
                    positionX = Math.random();
                    double vx = 50 * tmp + 100;

                    if (startingPositionX == 0) {
                        this.vx = vx;
                    } else {
                        this.vx = vx * -1;
                    }
                    rect.setX(rect.getX() + this.vx * dt);

                    //formule d'une fonction sinusoidale
                    double y = 25 * Math.sin(0.05 * (rect.getX() - startingPoint[0])) + startingPoint[1];
                    rect.setY(y);
                } else {
                    lostFishCount = 0;
                    fishDisapear = false;
                    totalTime = 0;
                    rect.setY(startingPositionY);
                    rect.setX(changeStartingX());
                    startingPositionX = rect.getX();
                }
            } else {
                lostFishCount = 0;
                totalTime = 0;
                rect.setY(startingPositionY);
                rect.setX(changeStartingX());
                startingPositionX = rect.getX();
                startingPoint[0] = rect.getX();
                startingPoint[1] = rect.getY();
            }
        }
    }

    @Override
    public void draw(GraphicsContext context) {

        if (!fishDisapear) {
            int frame = (int) (unchangedTotalTime * frameRateFish);

            Image img = fishImage[(frame % fishImage.length)];
            context.drawImage(img, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
        }
    }

    public double changeStartingY() {
        return (96 + Math.random() * 288);
    }

    public double changeStartingX() {
        double drouteOUgauche = Math.random();

        if (drouteOUgauche < 0.5) {
            imagePoisson(false);
            return 0;
        }

        imagePoisson(true);
        return 640;
    }

    public int getCounterLoss() {

        if (startingPositionX == 0) {
            if (rect.getX() >= 680 ||
                    rect.getY() <= -40 ||
                    rect.getY() + rect.getHeight() >= 520) {
                lostFishCount += 1;
                return lostFishCount;
            }
        } else {
            if (((int) rect.getX() <= -40 ||
                    ((int) rect.getY() <= -40 ||
                            (int) rect.getY() + rect.getHeight() >= 520))) {
                lostFishCount += 1;
                return lostFishCount;
            }
        }
        return 0;
    }

    public double getVx() {
        return vx;
    }

    public double getVy() {
        return vy;
    }

    public double getAx() {
        return ax;
    }

    public double getAy() {
        return ay;
    }


    public void setVx(double vx) {
        this.vx = vx;
    }

    public void setVy(double vy) {
        this.vy = vy;
    }

    public void setAx(double ax) {
        this.ax = ax;
    }

    public void setAy(double ay) {
        this.ay = ay;
    }
}

