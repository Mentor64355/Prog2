public class Data {
    public static int gameScore = 0;
}
