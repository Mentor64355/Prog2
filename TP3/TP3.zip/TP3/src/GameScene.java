import javafx.animation.AnimationTimer;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.FileNotFoundException;

public class GameScene {
    Scene play;
    Pane layout;
    boolean showScore = false;

    public GameScene(Scene scene, Stage primaryStage) {
        this.layout = new Pane();
        this.play = new Scene(layout, 640, 480);
        Canvas canvas = new Canvas(640, 480);
        layout.getChildren().add(canvas);

        GraphicsContext context = canvas.getGraphicsContext2D();
        Controller controller = new Controller();

        layout.setBackground(new Background(new BackgroundFill(Color.DARKBLUE, CornerRadii.EMPTY, Insets.EMPTY)));


        layout.setOnMouseMoved(controller::mouseMoved);
        layout.setOnMouseDragged(controller::mouseMoved);
        layout.setOnMouseClicked(controller::mouseClicked);
        play.addEventHandler(KeyEvent.KEY_PRESSED, (key) -> {
            controller.keyPressed(key.getCode());
        });

        AnimationTimer timer = new AnimationTimer() {
            private long timeStart = 0;

            @Override
            public void handle(long now) {
                if (timeStart == 0) {
                    timeStart = now;
                    return;
                }

                double deltaTime = (now - timeStart) * 1e-9;
                timeStart = now;

                if (!showScore) {
                    controller.update(deltaTime);
                    controller.draw(context);
                }

                if (controller.returnScore() && !showScore) {
                    showScore = true;
                    try {
                        SceneScore sceneScore = new SceneScore(scene, primaryStage, true, Data.gameScore);
                        primaryStage.setScene(sceneScore.getScene());
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        };
        timer.start();
    }

    public Scene getScene() {
        return play;
    }
}
