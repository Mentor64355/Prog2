import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Ball implements SceneObject {
    public static final double MIN_BALL_RADIUS = 0.01;
    double posX;
    double posY;

    double totalTime;

    CircleData circle;
    boolean actif = false;

    double deltaRayon = 0;

    public Ball() {
        circle = new CircleData(0, 0, 0, Color.BLACK);
    }

    @Override
    public void update(double dt, double level) {
        if (circle.getRadius() > MIN_BALL_RADIUS) {
            double rayon = circle.getRadius() + (-300) * dt;

            deltaRayon += (circle.getRadius() - rayon) / 2;

            if (rayon < MIN_BALL_RADIUS) {
                rayon = 0;

                posX = circle.getCenterX() + deltaRayon;
                posY = circle.getCenterY() + deltaRayon;


                deltaRayon = 0;
            }

            circle.setRadius(rayon);
        }else{
            actif = false;
            totalTime += dt;
        }
    }

    @Override
    public void draw(GraphicsContext context) {

        if (circle.getRadius() > MIN_BALL_RADIUS) {
            context.setFill(Color.BLACK);
            context.fillOval(circle.getCenterX() + deltaRayon,
                    circle.getCenterY() + deltaRayon,
                    circle.getRadius(),
                    circle.getRadius());
            //on ajoute deltaRayon pour que le rayon diminue au centre.

        }
    }

    public void setBalle(double x, double y) {
        this.circle.setCenterX(x);
        this.circle.setCenterY(y);
    }

    //Cette methode determine s'il y a une intersection avec le poissonNormaux et la balle
    public boolean normalFishIntersection(NormalFish p) {

        if (!actif) {
            return false;
        }

        double x = p.rect.getX();
        double y = p.rect.getY();
        double w = p.rect.getWidth();
        double h = p.rect.getHeight();

        if (posX > x && posX < x + w) {
            return posY > y && posY < y + h;
        }
        return false;
    }

    public boolean specialFishIntersection(SpecialFish p) {

        if (!actif) {
            return false;
        }

        double x = p.rect.getX();
        double y = p.rect.getY();
        double w = p.rect.getWidth();
        double h = p.rect.getHeight();

        if (posX > x && posX < x + w) {
            return posY > y && posY < y + h;
        }
        return false;
    }

    public void shot() {
        this.deltaRayon = 0;
        this.actif = true;
        this.circle.setRadius(100);
    }
}

