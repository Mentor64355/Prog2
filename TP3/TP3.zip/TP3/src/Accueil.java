import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.FileNotFoundException;


public class Accueil {
    Button buttonGame = new Button("Nouvelle Partie!");
    Button buttonScore = new Button("Meilleurs Scores");

    public Accueil(Pane root, GraphicsContext context, Scene scene, Stage primaryStage) {

        buttonGame.setLayoutX(280);
        buttonGame.setLayoutY(300);

        buttonScore.setLayoutX(280);
        buttonScore.setLayoutY(340);

        root.getChildren().add(buttonGame);
        root.getChildren().add(buttonScore);
        context.drawImage(new Image("/images/logo.png"), 180, 60, 300, 200);

        buttonGame.setOnAction(e -> {
            // Reinitialiser pour prochaine partie
            Data.gameScore = 0;
            primaryStage.setScene(new GameScene(scene, primaryStage).getScene());
        });

        buttonScore.setOnAction(e -> {
            try {
                primaryStage.setScene(new SceneScore(scene, primaryStage, false, 0).getScene());
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        });

        primaryStage.setTitle("Fish Hunt");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }


}
