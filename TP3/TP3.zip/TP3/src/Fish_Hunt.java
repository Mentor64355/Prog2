import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/***************

 Nom et matricule:
 Maya Moussaoui : 20157653
 Yasmin Jolasun : 20158274

 ***************/

public class Fish_Hunt extends Application {
    public Stage primaryStage;

    Accueil accueil;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;

        int w = 640;
        int h = 480;

        Pane root = new Pane();
        Scene scene = new Scene(root, w, h);
        Canvas canvas = new Canvas(w, h);

        root.setBackground(new Background(new BackgroundFill(Color.DARKBLUE, CornerRadii.EMPTY, Insets.EMPTY)));
        root.getChildren().add(canvas);
        GraphicsContext context = canvas.getGraphicsContext2D();

        accueil = new Accueil(root, context, scene, primaryStage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}