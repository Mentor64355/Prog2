import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;


public class Game {
    public static int WIDTH = 640;
    public static int HEIGHT = 480;

    public double time = 0;

    BubbleGroup[] bubbleList = new BubbleGroup[3];

    Scene scene = new Scene(20, 2);


    Ball ball = new Ball();
    Target target = new Target();


    NormalFish normalFish = new NormalFish();
    SpecialFish specialFish = new SpecialFish();


    public Game() {

        for (int i = 0; i < bubbleList.length; i++) {
            bubbleList[i] = new BubbleGroup();
        }
    }

    public void update(double dt) {
        time += dt;

        scene.update(dt);

        for (BubbleGroup groupeBulles : bubbleList) {
            groupeBulles.update(dt, scene.getLevel());
        }

        if (!scene.drawLevelChange) {
            if (scene.getLevel() != 1) {
                specialFish.update(dt, scene.getLevel());
            }
            normalFish.update(dt, scene.getLevel());
        }


        ball.update(dt, scene.getLevel());
        collisionsManager();

    }

    public void draw(GraphicsContext context) {
        scene.draw(context);

        if (!scene.drawLevelChange) {
            normalFish.draw(context);
            if (scene.getLevel() > 1) {
                specialFish.draw(context);
            }
        }

        ball.draw(context);
        target.draw(context);

        for (BubbleGroup bubbleGroup : bubbleList) {
            bubbleGroup.draw(context);
        }
    }


    public void mouseMoved(MouseEvent event) {
        double x = event.getX() - 25;
        double y = event.getY() - 25;
        ball.setBalle(x -25, y -25);
        target.setPos(x, y);
    }

    public void mouseClicked(MouseEvent event) {
        double x = event.getX() - 25;
        double y = event.getY() - 25;
        ball.shot();
        target.setPos(x, y);
    }

    public void collisionsManager() {
        if (ball.normalFishIntersection(normalFish)) {
            ball.actif = false;
            normalFish.fishDisapear = true;
            scene.pointsUp();

        }


        if (normalFish.startingPositionX == 0) {
            if (normalFish.rect.getX() >= 680 ||
                    normalFish.rect.getY() <= -40 ||
                    normalFish.rect.getY() + normalFish.rect.getHeight() >= 520) {
                if(normalFish.getCounterLoss() == 1){
                    scene.loseLife();
                }

            }
        }

        if (normalFish.startingPositionX == 640) {
            if (((int) normalFish.rect.getX() <= -40 ||
                    ((int) normalFish.rect.getY() <= -40 ||
                    (int) normalFish.rect.getY() + normalFish.rect.getHeight() >= 520))) {
                if(normalFish.getCounterLoss() == 1){
                    scene.loseLife();
                }
            }
        }


        if (ball.specialFishIntersection(specialFish)) {
            specialFish.fishDisapear = true;
            ball.actif = false;

            scene.pointsUp();

        }

        if (specialFish.startingPositionX == 0) {
            if (specialFish.rect.getX() >= 680 ||
                    specialFish.rect.getY() <= -40 ||
                    specialFish.rect.getY() + specialFish.rect.getHeight() >= 520) {
                if(specialFish.getCounterLoss() == 1){
                    scene.loseLife();
                }

            }
        }

        if (specialFish.startingPositionX == 640) {
            if (((int) specialFish.rect.getX() <= -40 ||
                    ((int) specialFish.rect.getY() <= -40 ||
                            (int) specialFish.rect.getY() + specialFish.rect.getHeight() >= 520))) {
                if(specialFish.getCounterLoss() == 1){
                    scene.loseLife();
                }
            }
        }
    }

    public void keyPressed(KeyCode key) {

        if (key == KeyCode.H) {
            scene.levelUp();
        }

        if (key == KeyCode.J) {
            scene.pointsUp();
        }

        if (key == KeyCode.K) {
            if(scene.lifeCount < 3 && scene.lifeCount > 0){
                scene.lifeUp();
            }
        }

        if (key == KeyCode.L) {
            scene.lostGame();
        }
    }

    public boolean returnScore() {
        return scene.gameOver;
    }
}
