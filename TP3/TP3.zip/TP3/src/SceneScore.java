import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.stage.Stage;

import java.io.*;
import java.util.*;


public class SceneScore {
    public Scene currentScene;
    public Button menuButton = new Button("Menu");
    public Button addButton = new Button("Ajouter");
    Label bestScores = new Label("Meilleurs scores ");
    ListView listView = new ListView();
    private final Pane layout;
    TextField textField = new TextField();
    public int finalCount;
    private int scorePlayer = 0;
    ArrayList<IndividualScore> scoreList = new ArrayList<>(10);


    public SceneScore(Scene scene, Stage primaryStage, boolean allowAdd, int score) throws FileNotFoundException {
        this.layout = new Pane();
        layout.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
        File file = new File("./src/scores.txt");
        FileReader fr = new FileReader(file);
        int count = 0;

        try {
            BufferedReader reader = new BufferedReader(fr);
            String s;
            String[] tmpTabS;
            while ((s = reader.readLine()) != null) {
                if (count < 10) {

                    tmpTabS = s.split("-");
                    if (tmpTabS.length != 3) {
                        continue;
                    }
                    IndividualScore individualScore = new IndividualScore(tmpTabS[1].trim(),
                            Integer.parseInt(tmpTabS[2].trim()));
                    scoreList.add(individualScore);
                }

                count += 1;
            }
            reader.close();
        } catch (IOException ex) {
            System.out.println("Erreur à l’ouverture du fichier");
        }

        for (int i = 0; i < scoreList.size(); i++) {
            listView.getItems().add(scoreList.get(i).formatter(i));
        }

        HBox addScoreBox = new HBox(5);
        addScoreBox.setAlignment(Pos.CENTER);
        addScoreBox.setPrefWidth(640);
        addScoreBox.getChildren().add(new Label("Votre nom: "));
        addScoreBox.getChildren().add(textField);
        addScoreBox.getChildren().add(new Label("a fait " + score + " points!"));
        addScoreBox.getChildren().add(addButton);

        VBox addScoreScene = new VBox(5);
        addScoreScene.setAlignment(Pos.CENTER);
        addScoreScene.setPrefWidth(640);
        addScoreScene.setPrefHeight(450);
        addScoreScene.setPadding(new Insets(30));
        bestScores.setFont(Font.font("verdana", FontPosture.REGULAR, 30));
        addScoreScene.getChildren().add(bestScores);
        addScoreScene.getChildren().add(listView);

        if (allowAdd) {
            addScoreScene.getChildren().add(addScoreBox);
        }
        addScoreScene.getChildren().add(menuButton);

        layout.getChildren().add(addScoreScene);

        this.currentScene = new Scene(layout, 640, 480); //640,480

        menuButton.setOnAction(e -> primaryStage.setScene(scene));

        finalCount = count;
        EventHandler<ActionEvent> event = e -> {
            try {
                FileWriter fw = new FileWriter(file);
                BufferedWriter writer = new BufferedWriter(fw);

                scoreList.add(new IndividualScore(textField.getCharacters().toString(), score));
                scoreList.sort(IndividualScore::compareTo);
                StringBuilder output = new StringBuilder();
                for (int i = 0; i < 10; i++) {

                    if (scoreList.size() <= i) {
                        break;
                    }
                    output.append(scoreList.get(i).formatter(i));
                    output.append('\n');
                }

                writer.append(output);

                writer.close();
            } catch (IOException ex) {
                System.out.println("Erreur à l’écriture du fichier");
            }

            primaryStage.setScene(scene);
        };

        addButton.setOnAction(event);
    }

    public Scene getScene() {
        return currentScene;
    }

    public Button getMenuButton() {
        return menuButton;
    }

    public Pane getLayout() {
        return layout;
    }

    public int getScorePlayer() {
        return scorePlayer;
    }

    public void setScorePlayer(int scorePlayer) {
        this.scorePlayer = scorePlayer;
    }
}
