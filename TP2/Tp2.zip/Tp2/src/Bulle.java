import javafx.scene.paint.Color;

public class Bulle {

    private double r;
    private double x, y;
    private Color color;
    private double vy;

    //innitialisation des dimenssion d'une bulle et sa vitess en y;
    public Bulle(double r, double x, double y, Color color) {
        this.r = r;
        this.x = x;
        this.y = y;
        this.color = color;
        vy = 350 + Math.random() * 100;
    }

    public void changeVitesse(){
        vy = 350 + Math.random() * 100;
    }

    public double getCenterX() {
        return x;
    }

    public double getCenterY() {
        return y;
    }

    public double getRadius() {
        return r;
    }

    public double getVy() {
        return vy;
    }

    public Color getColor() {
        return color;
    }


    public void setCenterX(double x) {
        this.x = x;
    }

    public void setCenterY(double y) {
        this.y = y;
    }

    public void setRadius(double r) {
        this.r = r;
    }

    public void setVy(double vy) {
        this.vy = vy;
    }

    public void setColor(Color color) {
        this.color = color;
    }
}