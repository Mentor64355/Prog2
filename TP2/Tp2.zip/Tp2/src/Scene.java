import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class Scene implements SceneObject {

    private double vy = 50;
    private double ay = 2;
    private double y;
    private double score = 0;


    //initializer la vitesse et l'acceleration de la scene
    public Scene(double vy, double ay) {
        this.vy = vy;
        this.ay = ay;
        y = 0;
    }

    //Si le jeu est en mode Debug, l'ecran ne descend que si la meduse depasse 75% de l'ecran
    //Sinon, l'ecran descend de plus en plus vite et les barres accelerante peuvent aussi faire
    //descendre l'ecran
    public void update(double dt,
                       boolean accelerate,
                       boolean scrollDown,
                       boolean modeDebug,
                       boolean gameStarted) {

        if(gameStarted){
            if (modeDebug) {
                double vy = 0;
                if (scrollDown) {
                    vy = 300; //this.vy * 10
                }
                y = dt * vy;
                score += y;
            } else {
                vy += dt * ay;
                double vy = this.vy;
                if (accelerate) {
                    vy *= 3;
                }

                if (scrollDown) {
                    vy = this.vy * 10;
                }

                y = dt * vy;
                score += y;
            }
        } else {
            //reinitialliser les donnees
            vy = 50;
            ay = 2;
            score = 0;
        }
    }

    @Override
    public void update(double dt, boolean gameStarted) {
    }

    @Override
    public void draw(GraphicsContext context, boolean modeDebug) {
        context.clearRect(0, 0, Jeu.WIDTH, Jeu.HEIGHT);

        //affichage du score en au de l'ecran, lorsque le jeu n'est pas en mode Debug
        context.setFill(Color.WHITE);
        context.setFont(Font.font("Arial Black", 28));
        context.fillText(Integer.toString((int) score) + " m", 125, 25);
    }

    public double getVy() {
        return vy;
    }

    public void setVy(double vy) {
        this.vy = vy;
    }

    public double getAy() {
        return ay;
    }

    public void setAy(double ay) {
        this.ay = ay;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getScore() {
        return score;
    }


}
