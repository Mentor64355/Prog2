import javafx.scene.paint.Color;

public class BarreData {

    private double x, y;
    private double w, h;
    private Color color;


    //crée un rectangle. Il ne fait rien d'autre
    public BarreData(double x, double y, double w, double h, Color color) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.color = color;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getW() {
        return w;
    }

    public double getH() {
        return h;
    }

    public Color getColor() {
        return color;
    }


    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public void setW(double w) {
        this.w = w;
    }

    public void setH(double h) {
        this.h = h;
    }

    public void setColor(Color color) {
        this.color = color;
    }
}