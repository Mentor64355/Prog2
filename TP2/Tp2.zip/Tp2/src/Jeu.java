import javafx.application.Platform;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;

//classe qui gere toutes les autre classe et communique avec le controlleur
public class Jeu {
    public static int WIDTH = 350;
    public static int HEIGHT = 480;
    public static boolean modeDebug = false;

    Meduse meduse = new Meduse("DROITE");
    Scene scene = new Scene(20, 2);
    GroupeBulle[] bullesList = new GroupeBulle[3];
    Barre[] listBar = new Barre[5];

    boolean accelerate = false;
    boolean gameStarted = false;

    //place les barres en sorte qu'elles ait des espacement egaux
    // et creer les 3 groupes de bulles
    public Jeu() {
        for (int i = 0; i < listBar.length; i++) {
            listBar[i] = new Barre(100 * i);
        }

        for (int i = 0; i < bullesList.length; i++) {
            bullesList[i] = new GroupeBulle();
        }
    }

    //quand le jeu commance, cette fonction ordonne a
    //toutes les classes de s'auto update
    public void update(double dt) {
        if (gameStarted) {


            //si la meduse tombe dans l'océan,
            //le jeu est terminé et on reviens au debut
            if (meduse.rect.getY() >= 480) {
                gameStarted = false;
                modeDebug = false;
            }
            scene.update(dt, accelerate, meduse.isTopScreen(), modeDebug, gameStarted);
            meduse.update(dt, gameStarted);
            meduse.rect.setY(meduse.rect.getY() + scene.getY());

            accelerate = false;

            for (GroupeBulle groupeBulles : bullesList) {
                groupeBulles.update(dt, gameStarted);
            }

            double topBarreY = Jeu.HEIGHT;
            for (Barre barre : listBar) {
                topBarreY =  Math.min(topBarreY,barre.getData().getY());
            }

            for (Barre barre : listBar) {
                barre.setTopBarreY(topBarreY);
                barre.update(scene.getY(), gameStarted);
            }
            handleCollision();
        }
    }

    //cette fonction se charge d' "ordonner" les autre classes
    // de dessiner se qu'il faut.
    public void draw(GraphicsContext context, double dt) {
        scene.draw(context, modeDebug);
        meduse.setScore(scene.getScore());
        meduse.draw(context, modeDebug);

        for (GroupeBulle groupeBulles : bullesList) {
            groupeBulles.draw(context, modeDebug);
        }

        for (Barre barre : listBar) {
            barre.draw(context, modeDebug);
        }
    }

    //permet de savoir si une certaine touche est appuiyé
    public void keyPressed(KeyCode key) {

        if (key == KeyCode.RIGHT) {

            if (!gameStarted) {
                gameStarted = true;
                meduse.setPosition("DROITE");
                meduse.setAx(1200);
            } else {
                meduse.setPosition("DROITE");
                if (meduse.rect.getX() + meduse.rect.getWidth() < 350) {
                    meduse.setAx(1200);
                }
            }
        }
        if (key == KeyCode.LEFT) {
            if (!gameStarted) {
                gameStarted = true;
                meduse.setPosition("GAUCHE");
                meduse.setAx(-1200);
            } else {
                meduse.setPosition("GAUCHE");
                if (meduse.rect.getX() > 0) {
                    meduse.setAx(-1200);
                }
            }
        }

        if (key == KeyCode.UP) {
            if (!gameStarted) {
                gameStarted = true;
                meduse.setVy(-600);
            } else {
                meduse.setPosition("HAUT");
                meduse.saut();
            }
        }

        if (key == KeyCode.T) {
            modeDebug = !modeDebug;
        }

        if (key == KeyCode.SPACE) {
            Platform.exit();
        }
    }

    //permet de savoir si une touche a ete relachee
    public void keyReleased(KeyCode key) {
        if (key == KeyCode.RIGHT) {
            meduse.setAx(0);
            meduse.setVx(0);
        }

        if (key == KeyCode.LEFT) {
            meduse.setAx(0);
            meduse.setVx(0);
        }
    }

    //cette fonction gere les collision entre les differentes barre et la meduse
    private void handleCollision() {
        for (Barre modelBarre : listBar) {


            if (modelBarre.doesCollide(meduse.rect.getX(),
                    meduse.rect.getY(),
                    meduse.rect.getWidth(),
                    meduse.rect.getHeight(), meduse.isSauter())) {

                boolean sauter = meduse.isSauter();
                boolean fromBottom = meduse.rect.getY() > modelBarre.getData().getY();
                modelBarre.setCollided(true);

                //si la meduse saute et que sa tete a une colision avec une barre
                // on ne fait, sauf si la barre est solide(renvoyer la meduse vers le bas)
                if (sauter) {
                    if (fromBottom) {
                        if (modelBarre.getType().equals(Barre.modelTypeSolide)) {
                            meduse.setVy(meduse.getVy() * -1);
                            meduse.rect.setY(meduse.rect.getY() + 10);
                        }
                    }
                    meduse.setStopped(false);

                } else {
                    //si la meduse ne saute pas et qu'elle se trouve au dessus d'une barre
                    // la meduse subbit des effets selon le type de la barre
                    if (!fromBottom && meduse.rect.getY() + meduse.rect.getHeight() - modelBarre.getData().getY() < 10) {
                        meduse.setStopped(true);
                        if (modelBarre.getType().equals(Barre.modelTypeRebondissant)) {
                            double maxVitesse = Math.min(meduse.getVy() * -1.5, -100);
                            meduse.setVy(maxVitesse);
                        } else if (modelBarre.getType().equals(Barre.modelTypeAccelerante)) {
                            accelerate = true;
                        }
                    }
                }
                break;

            } else {
                meduse.setStopped(false);
            }
        }
    }
}
