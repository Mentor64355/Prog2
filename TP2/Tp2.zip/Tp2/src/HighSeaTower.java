import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;

/****************

Nom et matricule:
 Yasmin Jolasun : 20158274
 Maya Moussaoui : 20157653


****************/




public class HighSeaTower extends Application {

    @Override
    //cree la scene pour le jeu et transmet les action du joueur
    //au controlleur
    public void start(Stage primaryStage) throws Exception {
        int w = 350;
        int h = 480;
        int y = 0;

        Pane root = new Pane();
        Scene scene = new Scene(root, w, h);
        Canvas canvas = new Canvas(w, h);

        root.getChildren().add(canvas);

        GraphicsContext context = canvas.getGraphicsContext2D();
        Controller controller = new Controller();

        scene.setFill(Color.DARKBLUE);

        scene.addEventHandler(KeyEvent.KEY_PRESSED, (key) -> {
            controller.keyPressed(key.getCode());
        });

        scene.addEventHandler(KeyEvent.KEY_RELEASED, (key) -> {
            controller.keyReleased(key.getCode());
        });

        //pour faire l'animation
        AnimationTimer timer = new AnimationTimer() {

            private long startTime = 0;

            @Override
            public void handle(long l) {

                if (startTime == 0) {
                    startTime = l;
                    return;
                }

                double deltaTime = (l - startTime) * 1e-9;
                startTime = l;
                controller.update(deltaTime);
                controller.draw(context, startTime);
            }
        };

        timer.start();

        primaryStage.setTitle("High Sea Tower");
        primaryStage.setScene(scene);
        primaryStage.show();
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
