import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

import java.util.ArrayList;

public class GroupeBulle implements SceneObject {

    ArrayList<Bulle> bulles = new ArrayList<>();
    private double totalTime = 0;

    //initiallise un groupe contenant 5 bulles
    public GroupeBulle() {
        Color colorBulles = Color.rgb(0, 0, 255, 0.4);
        double groupX = Math.random() * 350;

        for (int j = 0; j < 5; j++) {
            double signe = 1;
            if (Math.random() < 0.5) {
                signe = -1;
            }
            double rayon = 10 + (Math.random() * 30);

            bulles.add(j, new Bulle(rayon,
                    groupX + (signe * (Math.random() * 20)),
                    440 - (Math.random() * 10),
                    colorBulles));

            //empecher les bulles de depasser l'ecran du cote droit
            if (bulles.get(j).getCenterX() > 350) {
                bulles.get(j).setCenterX(350 - bulles.get(j).getRadius() * 2);
            }

            if ((bulles.get(j).getCenterX() + bulles.get(j).getRadius()) > 350) {
                bulles.get(j).setCenterX(350 - (bulles.get(j).getRadius()));
            }


            //empecher les bulles de depasser l'ecran du cote gauche
            if (bulles.get(j).getCenterX() < 0) {
                bulles.get(j).setCenterX(bulles.get(j).getRadius());
            }

            if ((bulles.get(j).getCenterX() + bulles.get(j).getRadius()) < 0) {
                bulles.get(j).setCenterX(bulles.get(j).getRadius() * 2);
            }
        }
    }

    @Override
    public void update(double dt, boolean gameStarted) {
        if (gameStarted) {
            totalTime += dt;

            for (Bulle bulle : bulles) {
                bulle.setCenterY(bulle.getCenterY() - dt * bulle.getVy());
            }

            //les bulles n'apparaissent sur l'ecran qu'a chaque 3 secondes
            if (totalTime >= 3) {
                totalTime = 0;
                double signe = 1;
                if (Math.random() < 0.5) {
                    signe = -1;
                }
                for (Bulle bulle : bulles) {
                    double groupX = Math.random() * 350;
                    bulle.changeVitesse();

                    //le centreX de chaque bulle ne depasse pas
                    // +- 20 du x du groupe où ils appartiennent
                    bulle.setCenterX(groupX + (signe * Math.random() * 20));

                    if (bulle.getCenterX() > 350) {
                        bulle.setCenterX(350 - bulle.getRadius());
                    }
                    if ((bulle.getCenterX() + bulle.getRadius()) > 350) {
                        bulle.setCenterX(350 - (bulle.getRadius()) * 2);
                    }

                    bulle.setCenterY(480);
                }
            }
        } else {
            //reinitialliser les donnees.
            //les bulles apparaissent des le debut de la partie
            totalTime = 3;
            for (Bulle bulle : bulles) {
                bulle.setCenterY(480);
            }

            for (Bulle bulle : bulles) {
                double groupX = Math.random() * 350;
                bulle.setVy(0);

                //le centreX de chaque bulle ne depasse pas
                // +- 20 du x du groupe où ils appartiennent
                bulle.setCenterX(groupX + ( Math.random() * 20));

                if (bulle.getCenterX() > 350) {
                    bulle.setCenterX(350 - bulle.getRadius());
                }
                if ((bulle.getCenterX() + bulle.getRadius()) > 350) {
                    bulle.setCenterX(350 - (bulle.getRadius()) * 2);
                }
            }
        }
    }

    @Override
    public void draw(GraphicsContext context, boolean modeDdebug) {

        //c'est une enhenced for boucle. sa veut juste dire
        // passe a travers chaque bulle de la liste bulles.
        for (Bulle bulle : bulles) {
            context.setFill(bulle.getColor());
            context.fillOval(bulle.getCenterX(),
                    bulle.getCenterY(),
                    bulle.getRadius(),
                    bulle.getRadius());
        }
    }
}
