import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;

public class Controller {
    Jeu jeu = new Jeu();

    //previen la classe jeu quand il faut mettre a jour le jeu
    public void update(double dt) {
        jeu.update(dt);
    }

    public void draw(GraphicsContext context,double dt) {
        jeu.draw(context,dt);
    }

    public void keyPressed(KeyCode key) {
        jeu.keyPressed(key);
    }

    public void keyReleased(KeyCode key) {
        jeu.keyReleased(key);
    }
}
