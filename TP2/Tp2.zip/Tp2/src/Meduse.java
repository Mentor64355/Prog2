import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;


public class Meduse implements SceneObject {
    Image[] framesGauche = new Image[6];
    Image[] framesDroite = new Image[6];
    double totalTime = 0;
    double frameRateMeduse = 8 * 1e-9;
    double totaleY = 0;


    Rectangle rect = new Rectangle(150, 430, 50, 50);
    private String position;
    boolean stopped = false;


    private double vx = 0;
    private double ax = 0;
    private double vy = 0;
    private double ay = 1200;


    //choisir la succession d'image selon la position
    //par defaut, la position est droite
    public Meduse(String position) {

        this.position = position;

        for (int i = 0; i < framesDroite.length; i++) {
            framesDroite[i] = new Image("/images/jellyfish" + (i + 1) + ".png");
        }


        for (int i = 0; i < framesGauche.length; i++) {
            framesGauche[i] = new Image("/images/jellyfish" + (i + 1) + "g.png");
        }

    }

    // changement de frame selon deplacement de meduse
    public Image[] imageChoice(String position) {

        if (!position.equals("DROITE")) {
            return framesGauche;
        }
        return framesDroite;
    }

    //calcule dela vitesse et du deplacement de la meduse
    // selon si la meduse est au "sol" ou au saut
    public void update(double dt, boolean gameStarted) {

        if(gameStarted){
            totalTime += dt;
            vx += dt * ax;
            rect.setX(rect.getX() + vx * dt);

            //pas de deplacement en y si la meduse est au "sol"
            if (!stopped) {
                vy += dt * ay;
                rect.setY(rect.getY() + vy * dt);
            }


            //empeche la meduse de depasser les bornes de x
            if (rect.getX() + rect.getWidth() > 350) {
                setVx(getVx() * -1);
            }

            if (rect.getX() < 0) {
                setVx(getVx() * -1);
            }

            //On devra l'enlever quans notre game over sera fait
            /*
            if (rect.getY() + rect.getHeight() > 480) {
                setVy(0);
            }

             */
        } else {
            //reinitialliser les donnees
            rect.setX(150);
            rect.setY(430);
            setAx(0);
            setVx(0);
        }
    }

    @Override
    public void draw(GraphicsContext context, boolean debugMode) {

        int frame = (int) (totalTime * frameRateMeduse);

        Image img = imageChoice(position)[(int) frame % imageChoice(position).length];

        //si en mode Debug, afficher les données de la meduse
        if (debugMode) {
            context.setFill(Color.rgb(255, 0, 0, 0.5));
            context.drawImage(img, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
            context.fillRect(rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());

            context.setFill(Color.WHITE);
            context.setFont(Font.font("Arial", 14));
            context.fillText("Position = (" + (int) rect.getX() + "," + (int) (rect.getY() + totaleY) + ")", 15, 15);
            context.fillText("v = (" + (int) vx + ", " + (int) vy + ")", 15, 35);
            context.fillText("a = (" + (int) ax + ", -" + (int) ay + ")", 15, 55);
            if (stopped) {
                context.fillText("Touche le sol: Oui", 15, 75);
            } else {
                context.fillText("Touche le sol: Non", 15, 75);
            }

        } else {
            context.drawImage(img, rect.getX(), rect.getY(), rect.getWidth(), rect.getHeight());
        }
    }

    //si la meduse est au "sol", la meduse saute
    public void saut() {
        if (stopped) {
            stopped = false;
            vy = -600;
        }
    }

    public boolean isSauter() {
        return vy < 0;
    }

    public boolean isTopScreen() {
        return rect.getY() < 120;
    }

    public boolean isStopped() {
        return stopped;
    }

    public double getVx() {
        return vx;
    }

    public double getVy() {
        return vy;
    }

    public double getAx() {
        return ax;
    }

    public double getAy() {
        return ay;
    }

    public String getPosition() {
        return position;
    }


    public void setVx(double vx) {
        this.vx = vx;
    }

    public void setVy(double vy) {
        this.vy = vy;
    }

    public void setAx(double ax) {
        this.ax = ax;
    }

    public void setAy(double ay) {
        this.ay = ay;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setScore(double score) { totaleY = score; }

    public void setStopped(boolean stopped) {
        this.stopped = stopped;
    }

}
