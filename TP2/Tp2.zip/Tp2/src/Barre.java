import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Barre implements SceneObject {
    //on definie tous les types qu'on peut avoir pour les barres
    public static final String modelTypeNormal = "NORMAL";
    public static final String modelTypeRebondissant = "REBONDISSANT";
    public static final String modelTypeAccelerante = "ACCELERANTE";
    public static final String modelTypeSolide = "SOLIDE";
    private String type;
    BarreData data = new BarreData(150, 430, 80 + Math.random() * 95, 10, Color.GREEN);
    private boolean released = false;
    private boolean collided = false;
    private String precedentType;
    private double topBarreY = 0;

    //initialiser les caracteristiques de la barre
    public Barre(double y) {
        this.type = getRandomType();
        precedentType = type;
        data.setY(y);
        generateFromType();
    }

    //generer les donné de la barre selon son type
    public void generateFromType() {
        getData().setW(80 + Math.random() * 95);
        getData().setX(Math.random() * (350 - getData().getW()));

        switch (this.type) {

            case modelTypeRebondissant:
                getData().setColor(Color.LIGHTGREEN);
                break;

            case modelTypeNormal:
                getData().setColor(Color.rgb(230, 134, 58));
                break;

            case modelTypeSolide:
                getData().setColor(Color.rgb(184, 15, 36));
                break;

            case modelTypeAccelerante:
                getData().setColor(Color.rgb(230, 221, 58));
                break;

            default:
                System.out.println("Type non valide: " + this.type);
                break;
        }
    }

    //montre s'il y a une collision
    public boolean doesCollide(double x, double y, double w, double h, boolean sauter) {
        boolean collide = getData().getX() < x + w &&
                getData().getX() + getData().getW() > x &&
                getData().getY() < y + h &&
                getData().getY() + getData().getH() > y;

        return collide;
    }

    //si la barre depasse les dimensions en y de l'ecran,
    //la faire remonter en haut et lui generer un nouveau type
    public void update(double y, boolean gameStarted) {
        if (gameStarted) {
            collided = false;
            data.setY(data.getY() + y);

            if (data.getY() >= 480) {
                data.setY(topBarreY - 100);

                setType(getRandomType());

                //si type est solide et type precedent est aussi solide
                //changer le type tant que le type actuel n'est plus solide
                while (getType().equals("SOLIDE") && precedentType.equals("SOLIDE")) {
                    setType(getRandomType());
                }

                generateFromType();
            }
        } else {
            //reinitialliser les donnees
            setType(getRandomType());
            generateFromType();
        }
    }

    @Override
    public void draw(GraphicsContext context, boolean modeDebug) {

        context.setFill(data.getColor());
        if (modeDebug && collided) {
            context.setFill(Color.YELLOW);
        } else {
            context.setFill(data.getColor());
        }
        context.fillRect(data.getX(), data.getY(), data.getW(), data.getH());
    }

    private String getRandomType() {
        double rand = Math.random();

        if (0 <= rand && rand < 0.65) {
            return Barre.modelTypeNormal;
        }

        if (0.65 <= rand && rand < 0.75) {
            return Barre.modelTypeAccelerante;
        }
        if (0.75 <= rand && rand < 0.95) {
            return Barre.modelTypeRebondissant;
        }

        return Barre.modelTypeSolide;
    }

    public boolean isCollided() {
        return collided;
    }

    public String getType() {
        return type;
    }

    public BarreData getData() {
        return data;
    }

    public boolean getReleased() {
        return released;
    }

    public double getTopBarreY() {
        return topBarreY;
    }


    public void setCollided(boolean collided) {
        this.collided = collided;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setReleased(boolean released) {
        this.released = released;
    }

    public void setTopBarreY(double topBarreY) {
        this.topBarreY = topBarreY;
    }
}
