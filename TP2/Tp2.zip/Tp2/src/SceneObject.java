import javafx.scene.canvas.GraphicsContext;

public interface SceneObject {
    void update(double dt, boolean gameStarted);
    void draw(GraphicsContext context, boolean debugMode);
}
